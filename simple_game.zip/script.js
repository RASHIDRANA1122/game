
const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const startBtn = document.getElementById('start');
let w = canvas.width, h = canvas.height;
let circle = {x:300,y:200,r:30,dx:3,dy:2};
let score = 0;
let running = false;
let timeLeft = 30;
let timerId = null;

function reset(){
  score = 0; timeLeft = 30;
  circle.x = Math.random()*(w-60)+30;
  circle.y = Math.random()*(h-60)+30;
  circle.dx = (Math.random()>0.5?1:-1)*(2+Math.random()*3);
  circle.dy = (Math.random()>0.5?1:-1)*(2+Math.random()*3);
  scoreEl.textContent = 'Score: ' + score;
}

function draw(){
  ctx.clearRect(0,0,w,h);
  // draw circle
  ctx.beginPath();
  ctx.fillStyle = '#ffcc00';
  ctx.arc(circle.x, circle.y, circle.r, 0, Math.PI*2);
  ctx.fill();
  ctx.closePath();
  // draw time
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px monospace';
  ctx.fillText('Time: ' + timeLeft.toFixed(0) + 's', 10, 20);
  ctx.fillText('Score: ' + score, 10, 40);
}

function update(){
  if(!running) return;
  circle.x += circle.dx;
  circle.y += circle.dy;
  if(circle.x < circle.r || circle.x > w-circle.r) circle.dx *= -1;
  if(circle.y < circle.r || circle.y > h-circle.r) circle.dy *= -1;
  draw();
  requestAnimationFrame(update);
}

canvas.addEventListener('click', (e)=>{
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  const dist = Math.hypot(mx - circle.x, my - circle.y);
  if(dist <= circle.r){
    score += 1;
    // move circle randomly
    circle.x = Math.random()*(w-60)+30;
    circle.y = Math.random()*(h-60)+30;
    circle.dx *= 1.05; circle.dy *= 1.05;
    scoreEl.textContent = 'Score: ' + score;
  }
});

startBtn.addEventListener('click', ()=>{
  if(running){ // stop
    stopGame();
    startBtn.textContent = 'Start Game';
  } else {
    reset();
    startGame();
    startBtn.textContent = 'Stop';
  }
});

function startGame(){
  running = true;
  draw();
  update();
  timerId = setInterval(()=>{
    timeLeft -= 1;
    if(timeLeft <= 0){
      stopGame();
      alert('Game over! Your score: ' + score);
      startBtn.textContent = 'Start Game';
    }
  }, 1000);
}

function stopGame(){
  running = false;
  if(timerId) clearInterval(timerId);
}

window.addEventListener('resize', ()=>{
  // keep canvas fixed size for simplicity
});

function shareLink(){
  const url = location.href;
  if(navigator.share){
    navigator.share({title:'Play Click Collector',text:'Try my game!',url}).catch(()=>{});
  } else {
    prompt('Copy and share this link:', url);
  }
}

// Friendly: if opened directly as file, give basic instructions
if(location.protocol === 'file:'){
  // nothing special
}
