
Click Collector - Simple HTML5 mini-game
Files:
 - index.html  (main game)
 - style.css   (styles)
 - script.js   (game logic)
 - favicon.svg (icon)

How to host:
1) Upload the folder 'simple_game' to any static host (GitHub Pages, Netlify, itch.io, or your web server).
2) Open index.html in browser to play. If you host online, copy the public URL and post it on Facebook.

If you want, I can guide you step-by-step to host this on GitHub Pages or itch.io.
